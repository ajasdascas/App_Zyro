package com.example.zyra

import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import com.example.prueba2.R

class SignupActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Cargar tu layout
        setContentView(R.layout.login_activity)

        // Manejar botón de retroceso (flecha)
        val backButton = findViewById<ImageButton>(R.id.backButton)
        backButton.setOnClickListener {
            finish() // Cierra esta pantalla y vuelve a la anterior
        }
    }
}
